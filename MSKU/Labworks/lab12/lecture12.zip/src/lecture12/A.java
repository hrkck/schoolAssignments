package lecture12;

public class A {


	public static class B{
		 public static void main(String[] args){
			 System.out.println("Hello");
		 }
	}
}
