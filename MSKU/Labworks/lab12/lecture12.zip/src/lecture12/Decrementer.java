package lecture12;

public class Decrementer implements Runnable {

	Counter c;
	int amount;
	public Decrementer(Counter c, int amount){
		this.c =c;
		this.amount = amount;
	}
	
	@Override
	public void run() {
		for (int i =0; i<amount; i++){
			c.decrement();
		}

	}

}
