package lecture12;

public class HelloRunnable extends Thread {

	@Override
	public void run() {
		for (int i = 0; i< 20; i++){
			System.out.println("Hello" +i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				System.out.println("Thread interrupted");
				return;
			}
		}

	}

	public static void main(String[] args) throws InterruptedException{
		Thread t1 = new HelloRunnable();
		t1.start();
		
		for (int i = 0; i< 10 ; i++){
			System.out.println("Main:" + i);
			Thread.sleep(1000);
			if (i == 5){
				System.out.println("Joining T1");
				t1.join();
				System.out.println("T1 has finished");

			}
		}
	}
	
}
