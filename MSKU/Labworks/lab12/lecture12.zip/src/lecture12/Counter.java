package lecture12;

public class Counter {
    private int c = 0;
    
    Object obj = new Object();
    public void increment() {
    	synchronized (obj) {
    		c++;
		}
    		
    
    }

    public void decrement() {
    		synchronized (obj) {
    			c--;
			}
    		
       
    }

    public int value() {
        return c;
    }

    public static void main(String[] args) throws InterruptedException{
    	Counter c = new Counter();
    	Thread t1 = new Thread(new Incrementer(c, 1000));
    	Thread t2 = new Thread(new Decrementer(c, 1000));
    	t1.start();
    	t2.start();
    	t1.join();
    	t2.join();
    	System.out.println(c.value());
    }
    
}