package lecture12;

public class Deadlock implements Runnable {

	Object obj1;
	Object obj2;
	
	Deadlock (Object obj1, Object obj2){
		this.obj1 = obj1;
		this.obj2 = obj2;
	}
	
	@Override
	public void run() {
		synchronized (obj1) {
			work();
			System.out.println(Thread.currentThread() + " Finished first");
			synchronized (obj2) {
				System.out.println(Thread.currentThread() + " Starting second");
				work();
			}
		}


	}

	private void work() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) throws InterruptedException {
		Object obj1 = new Object();
		Object obj2 = new Object();
		Thread t1 = new Thread(new Deadlock(obj1, obj2));
		Thread t2 = new Thread(new Deadlock(obj2, obj1));
		t1.start();
		t2.start();
		
		t1.join();
		System.out.println("Main ends");
		
	}

}
