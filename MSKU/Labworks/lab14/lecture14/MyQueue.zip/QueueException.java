
public class QueueException extends Exception {

	public QueueException(String mesage){
		super(mesage);
	}
}
