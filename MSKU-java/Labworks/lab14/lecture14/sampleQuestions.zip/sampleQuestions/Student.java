package sampleQuestions;

public class Student {
	private String id;
	private int score;
	public Student(String id, int score) {
		super();
		this.id = id;
		this.score = score;
	}
	public String getId() {
		return id;
	}
	public int getScore() {
		return score;
	}
}
