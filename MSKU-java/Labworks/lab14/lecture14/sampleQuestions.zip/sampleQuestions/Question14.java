package sampleQuestions;

public class Question14 {
	int a;
	int b;
	public Question14(int a, int b) {
		a = a;
		this.b = b;
	}
	public static void main(String[] args) {
		Question14 s = new Question14(37, 47);
		System.out.println("a = " + s.a);
		System.out.println("b = " + s.b);
	}
}