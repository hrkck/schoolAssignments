package org.tweet.sentiment.analyis.fetcher.model;

public class Term {

    private String identifier;

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }
}
