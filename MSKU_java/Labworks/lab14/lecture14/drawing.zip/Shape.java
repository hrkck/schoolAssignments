
public abstract class Shape {

	public abstract int calculateArea();	
}
