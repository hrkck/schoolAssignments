package lab12;

import java.util.LinkedList;

public class Queue {

	LinkedList<Integer> queue = new LinkedList<Integer>();
	
	public Queue(){
		
	}
	
	public synchronized void add(Integer number){
		queue.add(number);
		notifyAll();
	}
	

	public synchronized Integer remove() throws InterruptedException{
		while (queue.isEmpty()){
			wait();
		}
		return queue.remove();
	}
	
	public synchronized boolean isEmpty(){
		return queue.isEmpty();
	}
	
	
	public synchronized int size(){
		return queue.size();
	}
	
	public static void main(String[] args) throws InterruptedException {
		Queue queue = new Queue();
		Producer prod1 = new Producer(queue);
		Producer prod2 = new Producer(queue);
		Consumer cons = new Consumer(queue);
		
		cons.start();
		prod1.start();
		prod2.start();
		
		prod1.join();
		prod2.join();
		while (!queue.isEmpty()){
			System.out.println("Queue is not Empty");
		}
		cons.interrupt();
		System.out.println(queue.size());
		
		
		Runnable aRunnable = new Runnable(){

			String a;
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
			
		};
		
		Thread t = new Thread(aRunnable);
		
	}

}

