package lecture11;

import java.util.ArrayList;
import java.util.List;

public class Invoice {

	private List<InvoiceItem> items = new ArrayList<>();

	public List<InvoiceItem> getItems() {
		return items;
	}
	
	
	
}
