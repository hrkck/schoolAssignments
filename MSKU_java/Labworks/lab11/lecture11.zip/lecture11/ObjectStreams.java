package lecture11;

/*
 * Copyright (c) 1995, 2008, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.io.EOFException;

public class ObjectStreams {
    static final String objectFile = "invoiceobj";

    public static void main(String[] args) throws IOException, ClassNotFoundException {
    	ObjectStreams os = new ObjectStreams();
 
    	Invoice2  inv = os.readInvoice(objectFile);
//    	Invoice2  inv = new Invoice2();
//    	inv.getItems().add(new InvoiceItem2(new BigDecimal("19.99"), 12, "Java T-shirt"));
//    	inv.getItems().add(new InvoiceItem2(new BigDecimal("9.99"), 8, "Java Mug"));
//    	inv.getItems().add(new InvoiceItem2(new BigDecimal("15.99"), 13, "Duke Juggling Dolls"));
//    	inv.getItems().add(new InvoiceItem2(new BigDecimal("3.99"), 29, "Java Pin"));
//    	inv.getItems().add(new InvoiceItem2(new BigDecimal("4.99"), 50, "Java Key Chain"));
//
    	os.printInvoice(inv);
//    	os.writeInvoice(inv, objectFile);


    	
    	
    }
    
    public void writeInvoice(Invoice2  inv, String file) throws IOException{
    	ObjectOutputStream out = null;
        
        try {
            out = new ObjectOutputStream(new
                    BufferedOutputStream(new FileOutputStream(file)));

            for (InvoiceItem2 item: inv.getItems()) {
                out.writeObject(item);
                
            }
            
        } finally {
            out.close();
        }
    }
    
    public Invoice2 readInvoice(String file) throws IOException, ClassNotFoundException{
    	Invoice2 inv = new Invoice2();
    	ObjectInputStream in = null;
        try {
            in = new ObjectInputStream(new
                    BufferedInputStream(new FileInputStream(file)));
     
            BigDecimal price;
            int unit;
            String desc;

            try {
                while (true) {   	
                	InvoiceItem2 item = (InvoiceItem2)in.readObject();
                    inv.getItems().add(item);
               }
            } catch (EOFException e) { 
            	System.out.println("File ended.");
            }
            
        }
        finally {
            in.close();
        } 
        return inv;
    }
    
    private void printInvoice(Invoice2 inv){
        double total = 0.0;
        
    	for (InvoiceItem2 item: inv.getItems()) {
            System.out.format("You ordered %d units of %s at $%.2f%n",
            		item.getUnit(), item.getDesc(), item.getPrice());
            total += item.getUnit() * item.getPrice().doubleValue();
        }
        System.out.format("For a TOTAL of: $%.2f%n", total);    	
    }
}