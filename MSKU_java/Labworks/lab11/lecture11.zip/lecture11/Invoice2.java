package lecture11;

import java.util.ArrayList;
import java.util.List;

public class Invoice2 {

	private List<InvoiceItem2> items = new ArrayList<>();

	public List<InvoiceItem2> getItems() {
		return items;
	}
	
	
	
}
