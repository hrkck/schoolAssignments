package lecture11;

public class InvoiceItem {
	private double price;
	private int unit;
	private String desc;
	
	public InvoiceItem(double price, int unit, String desc) {
		super();
		this.price = price;
		this.unit = unit;
		this.desc = desc;
	}

	public double getPrice() {
		return price;
	}

	public int getUnit() {
		return unit;
	}

	public String getDesc() {
		return desc;
	}
	
}
