package lecture11;

import java.io.Serializable;
import java.math.BigDecimal;

public class InvoiceItem2 implements Serializable{
	private BigDecimal price;
	private int unit;
	private String desc;
	
	public InvoiceItem2(BigDecimal price, int unit, String desc) {
		super();
		this.price = price;
		this.unit = unit;
		this.desc = desc;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public int getUnit() {
		return unit;
	}

	public String getDesc() {
		return desc;
	}
	
}
