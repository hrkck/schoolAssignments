package lecture11;

import java.math.BigDecimal;

public class DoubleAndBigDecimal {

	public static void main(String[] args) {
		double val = 0.3; 
		System.out.println(val/6);

		BigDecimal bd = new BigDecimal("0.324");
		System.out.println(bd.divide(new BigDecimal(6)));
	}

}
